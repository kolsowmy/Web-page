export class Department {
    
    department_id:number=0;
        department_name:string='';
        // desc:string='';
        // no_of_Emp:number=0;
        
    
}
