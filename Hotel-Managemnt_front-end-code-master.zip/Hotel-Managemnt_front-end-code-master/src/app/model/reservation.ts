export class Reservation {
    bookingId:number=0;
    roomId:number=0;
    checkin:string='';
    checkout:string='';
    numOfGuests:number=0;
    finalPrice:number=0;
}
