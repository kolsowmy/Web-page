export class Room {
    roomId: number=0;
    roomCharges:number=0;
    roomType: string="";
    roomDesc: string="";
    roomAvl: boolean = false;
  static bookingId: any;
  
}
