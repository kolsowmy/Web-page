export class Inventory {

    inventory_id : number=0;
    inventory_name : string="";
    
}
