export class Staff {

    empId:number=0;
    empDeptId:number=0;
    empName:string='';
    empDeptName:string='';
    email:string='';
    empSalary:number=0;

}
