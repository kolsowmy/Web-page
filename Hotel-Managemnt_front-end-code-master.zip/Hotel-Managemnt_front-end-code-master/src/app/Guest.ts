// import * as internal from "stream";

export class Guest{
    guestId!: number;
    guestName!: String;
    guestEmail!: string;
    guestCotact!: number;
    guestAddress!: string;
  guestContact: any;
  guestGender: any;
  allGuest: any;


}